package co.in.nextgencoder.serviceIMPL;

import android.view.View;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import co.in.nextgencoder.model.User;
import co.in.nextgencoder.service.UserService;
import co.in.nextgencoder.util.CallBack;
import co.in.nextgencoder.util.CallBackWithView;

public class UserServiceIMPL implements UserService {

    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;

    public UserServiceIMPL() {
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
    }

    @Override
    public void updateUser(CallBack<Boolean> finishedCallBack, User user) {

    }

    @Override
    public void getSurvey(CallBack<Boolean> finishedCallBack, String id, Double height, Double weight) {
        DatabaseReference userReference = databaseReference.child("users").child(id);
        userReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userReference.child("height").setValue(height);
                userReference.child("weight").setValue(weight);
                finishedCallBack.callback(true);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                finishedCallBack.callback(false);
            }
        });
    }

    @Override
    public void addUser(@NonNull final CallBack<Boolean> finishedCallback, User user) {
        databaseReference.child("users").child(firebaseAuth.getUid()).setValue(user)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if( task.isSuccessful()) {
                            finishedCallback.callback( true);
                        } else {
                            finishedCallback.callback( false);
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        finishedCallback.callback( false);
                    }
                });
    }

    @Override
    public void allUser(@NonNull final CallBack<List<User>> finishedCallback) {
        databaseReference.child("users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<User> searchedData = new ArrayList<User>();
                for ( DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    User user = dataSnapshot.getValue( User.class);
                    searchedData.add(user);
                }
                finishedCallback.callback( searchedData);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public void editUserBioById(@NonNull final CallBack<Boolean> finishedCallback, String id, final String bio) {
        final DatabaseReference userReference = databaseReference.child("users").child(id);
        userReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userReference.child("bio").setValue(bio);
                finishedCallback.callback( true);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                finishedCallback.callback( true);
            }
        });
    }

    @Override
    public void deleteUser(@NonNull CallBack<Boolean> finishedCallback, User user) {
        // Feature Yet to be added
    }

    @Override
    public void searchUserByName(@NonNull final CallBack<List<User>> finishedCallback, final String name) {
        databaseReference.child("users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<User> searchedData = new ArrayList<User>();

                for ( DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    if (dataSnapshot.child("name").getValue().toString().toLowerCase().contains( name.toLowerCase())) {
                        searchedData.add( dataSnapshot.getValue(User.class));
                    }
                }
                finishedCallback.callback( searchedData);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public View isSurveySubmitted(@NonNull CallBackWithView<Boolean> finishedCallback, String id) {
        databaseReference.child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User user = snapshot.getValue( User.class);
                try {
                    if( user.getHeight()==0 && user.getWeight()==0) {
                        finishedCallback.callback( false);
                    } else {
                        finishedCallback.callback( true);
                    }
                } catch ( NullPointerException nullPointerException ) {
                    finishedCallback.callback( false);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public void getUserById(@NonNull final CallBack<User> finishedCallback, final String id) {
        databaseReference.child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                System.out.println("id ======> "+id);
                User user = snapshot.getValue( User.class);
                finishedCallback.callback(user);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

}
