package co.in.nextgencoder;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import co.in.nextgencoder.model.Dish;

public class DishAdapter extends RecyclerView.Adapter<DishAdapter.ViewHolder> {

    private List<Dish> dish;

    public DishAdapter(List<Dish> dish) {
        this.dish = dish;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.item_diet, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override public void onBindViewHolder(final ViewHolder holder, final int position) {
        final Dish newDish = dish.get(position);
        holder.name.setText( dish.get(position).getName());
        holder.type.setText( dish.get(position).getType());
        holder.calories.setText( dish.get(position).getCalories());
    }

    @Override
    public int getItemCount() {
        return dish.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView name;
        public ImageView image;
        public TextView type;
        public TextView mealType;
        public TextView calories;
        public TextView taste;

        public RelativeLayout relativeLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            this.name = (TextView) itemView.findViewById(R.id.dishName);
            this.type = (TextView) itemView.findViewById(R.id.dishType);
            this.calories = (TextView) itemView.findViewById(R.id.dishCalories);
            relativeLayout = (RelativeLayout)itemView.findViewById(R.id.item_diet);
        }
    }
}
