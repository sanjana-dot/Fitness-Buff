package co.in.nextgencoder.util;


public interface CallBack<T> {
    public void callback( T t);
}