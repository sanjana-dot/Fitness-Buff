package co.in.nextgencoder.service;

import android.view.View;

import androidx.annotation.NonNull;

import java.util.List;

import co.in.nextgencoder.model.User;
import co.in.nextgencoder.util.CallBack;
import co.in.nextgencoder.util.CallBackWithView;

public interface UserService {
    public void updateUser(CallBack<Boolean> finishedCallBack, User user);

    public void getSurvey(CallBack<Boolean> finishedCallBack, String id, Double height , Double weight);

    public void addUser(@NonNull CallBack<Boolean> finishedCallback, User user);

    public void allUser(@NonNull CallBack<List<User>> finishedCallback);

    public void editUserBioById(@NonNull CallBack<Boolean> finishedCallback, String id, String bio);

    public void deleteUser(@NonNull CallBack<Boolean> finishedCallback, User user);

    public void searchUserByName(@NonNull CallBack<List<User>> finishedCallback, String name);

    public View isSurveySubmitted(@NonNull CallBackWithView<Boolean> finishedCallback, String id);

    public void getUserById(@NonNull CallBack<User> finishedCallback, String id);
}
