package co.in.nextgencoder.model;

public class Dish {

    private String name;
    private String image;
    private String type;
    private String mealType;
    private String calories;
    private String taste;

    public Dish() { }

    public Dish(String name, String image, String type, String mealType, String calories, String taste) {
        this.name = name;
        this.image = image;
        this.type = type;
        this.mealType = mealType;
        this.calories = calories;
        this.taste = taste;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMealType() {
        return mealType;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

    public String getCalories() {
        return calories;
    }

    public void setCalories(String calories) {
        this.calories = calories;
    }

    public String getTaste() {
        return taste;
    }

    public void setTaste(String taste) {
        this.taste = taste;
    }
}
