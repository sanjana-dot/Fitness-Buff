package co.in.nextgencoder;

import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import co.in.nextgencoder.model.Dish;
import co.in.nextgencoder.service.UserService;
import co.in.nextgencoder.serviceIMPL.UserServiceIMPL;
import co.in.nextgencoder.util.CallBack;
import co.in.nextgencoder.util.CallBackWithView;


public class DietFragment extends Fragment {

    private UserService userService = new UserServiceIMPL();
    private EditText heightEdit, weightEdit;
    private Button surveySubmitButton;
    private RecyclerView dietRecyclerView;

    private FirebaseAuth firebaseAuth;
    private boolean isSurveyOn;

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        firebaseAuth = FirebaseAuth.getInstance();

         View dietFrag = inflater.inflate(R.layout.fragment_diet, container, false);
         View surveyFrag = inflater.inflate(R.layout.fragment_survey, container, false);

         View returningView = userService.isSurveySubmitted(isSurveySubmitted -> {
             if( !isSurveySubmitted) {
                 heightEdit = surveyFrag.findViewById(R.id.heightEdit);
                 weightEdit = surveyFrag.findViewById(R.id.weightEdit);
                 surveySubmitButton = surveyFrag.findViewById(R.id.surveySubmitButton);

                 surveySubmitButton.setOnClickListener(v -> {
                     submitSurvey();
                 });

                 return surveyFrag;
             } else {
                 dietRecyclerView = dietFrag.findViewById( R.id.dietRecyclerView);

                 List<Dish> dishes = new ArrayList<Dish>();
                 dishes.add( new Dish( "Biryani", "", "Non-Veg", "Dinner", "1000", "Spicy"));
                 dishes.add( new Dish( "Gulab Jamun", "", "Veg", "Lunch", "400", "Sweet"));

                 DishAdapter dishAdapter = new DishAdapter( dishes);
                 dietRecyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
                 dietRecyclerView.setAdapter( dishAdapter);

                 return dietFrag;
             }
         }, firebaseAuth.getUid());

        System.out.println("======>"+returningView);

        return returningView;
    }

    public void submitSurvey() {
        Double height = Double.parseDouble(heightEdit.getText().toString()) ;
        Double weight = Double.parseDouble(weightEdit.getText().toString()) ;

        userService.getSurvey(isSuccessful -> {
            if(isSuccessful){
                Toast.makeText( getContext(), "Survey Submitted", Toast.LENGTH_SHORT).show();
            }
        }, firebaseAuth.getUid(), height, weight);
    }
}