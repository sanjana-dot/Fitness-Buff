package co.in.nextgencoder.util;


import android.view.View;

public interface CallBackWithView<T> {
    public View callback(T t);
}